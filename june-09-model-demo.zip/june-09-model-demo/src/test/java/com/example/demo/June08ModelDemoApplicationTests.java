package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class June08ModelDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
