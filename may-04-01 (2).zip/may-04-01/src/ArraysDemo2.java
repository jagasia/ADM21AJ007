import java.util.Arrays;
import java.util.List;

public class ArraysDemo2 {

	public static void display(Integer ...arr)
	{
		for(Integer a:arr)
			System.out.println(a);
		System.out.println("--------------------");
	}
	
	public static void main(String[] args) {
//		List<Integer> marks=Arrays.asList(2,3,4,5,6,7,8);
		Integer []arr= {1,100,55,3,33,19};
		display(arr);
		
		display(100,200);
		
		display(1,90,3,4,2);
	}

}
