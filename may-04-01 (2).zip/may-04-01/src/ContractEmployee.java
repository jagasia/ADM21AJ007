
public class ContractEmployee extends Employee{

	public ContractEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ContractEmployee(Integer id, String firstName, String lastName, Double salary) {
		super(id, firstName, lastName, salary);
		
	}
	
}
