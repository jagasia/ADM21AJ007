import java.util.Arrays;

public class ArraysSort {

	public static void main(String[] args) {
		Integer marks[]= {90,100,20,60,49,30,50};
		Arrays.sort(marks, (a,b)->b-a);
		System.out.println(Arrays.toString(marks));
	}

}
