import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class StringComparator implements Comparator<String>
{

	@Override
	public int compare(String o1, String o2) {
		// TODO Auto-generated method stub
		//sb.toString().length()
		return o1.length()-o2.length();
	}
	
}
public class StringComparatorDemo {

	public static void main(String[] args) {
		List<String> countries=new ArrayList<>();
		countries.add("Ice land");
		countries.add("India");
		countries.add("Australia");
		countries.add("Pakistan");
		countries.add("Sri lanka");
		countries.add("Japan");
		countries.add("Bangladesh");
		//sort the countries based on their lenght
//		Collections.sort(countries, (a,b)->b.length()-a.length());
		Collections.sort(countries, new StringComparator());
		for(String c:countries)
			System.out.println(c);
	}

}
