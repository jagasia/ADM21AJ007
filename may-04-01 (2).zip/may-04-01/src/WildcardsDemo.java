import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class WildcardsDemo {
	
	public static void display(List<? super ContractEmployee> arr)
	{
		Iterator<?> it = arr.iterator();
		while(it.hasNext())
			System.out.println(it.next());
	}
	public static void main(String[] args) {
		List<ContractEmployee> e=new ArrayList<>();
		e.add(new ContractEmployee(1, "Ram", "Kumar", 1234567.0));
		e.add(new ContractEmployee(1, "Ram", "Kumar", 1234567.0));
		e.add(new ContractEmployee(2, "Siva", "Kumar", 84383.0));
		e.add(new ContractEmployee(3, "Rama", "Krishna", 747474.0));
		e.add(new ContractEmployee(1, "Ram", "Kumar", 1234567.0));
		e.add(new ContractEmployee(4, "Siva", "Raja", 383838.0));
		e.add(new ContractEmployee(5, "Rama", "Nathan", 199111.0));
		e.add(new ContractEmployee(6, "John", "Kennedy", 1024567.0));
		e.add(new ContractEmployee(1, "Ram", "Kumar", 1234567.0));
		display(e);
	}

}
