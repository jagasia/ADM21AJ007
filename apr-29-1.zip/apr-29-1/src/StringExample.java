
public class StringExample {

	public static void main(String[] args) {
		String str1=new String("Hello");
		String str2=new String("Hello1");
//		System.out.println(str1==str2);
		System.out.println(str1.equals(str2));
		System.out.println(str1.compareTo(str2));
	}

}
