package rps;

import cts.Employee;

public class ContractEmployee extends Employee
{
	public void method1()
	{
		System.out.println(employeeId);		//public CAN ACCESS
//		System.out.println(salary);			//private CANNOT access
		System.out.println(name);			//protected ACCESSIBLE IN SUB CLASS
//		System.out.println(phoneNo); 		//default CANNOT access
	}
}
