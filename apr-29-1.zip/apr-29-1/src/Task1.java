import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter the input string");
		String input=sc.next();
		//need each character in the string
		char[] carr = input.toCharArray();
		for(char c : carr)
		{
			
			//how i can find if c is a digit? or letter?
			if(Character.isLetter(c))
				System.out.println(c+" is a letter");
			else if(Character.isDigit(c))
				System.out.println(c+" is a digit");
			else
				System.out.println(c+" might be a symbol");
		}
	}

}
