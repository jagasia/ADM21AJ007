import java.util.Scanner;

public class Chair extends Furniture{
	int noOfLegs;
	public void acceptDetails()
	{
		super.acceptDetails();
		Scanner sc=new Scanner(System.in);
		System.out.println("No of legs:");
		noOfLegs=sc.nextInt();	
	}
	public void displayDetails()
	{
		super.displayDetails();
		System.out.println("No of legs:"+noOfLegs);
	}
}
