class Student
{
	static String collegeName;		//shared by all objects of Student class
	Long phoneNo;

	public static void speak()
	{		
			System.out.println("Student speaks");
	}
	
	public void attendClass()
	{
		System.out.println("Student attends class");
	}
}

public class Main {
	public static void main(String[] args) {		
//		Student.speak();
		Student rama, siva;
		rama=new Student();
		siva=new Student();
		
		//there are 2 objects of Student class. But there exists only 1 instance of static member
		Student.collegeName="LPU";
		System.out.println(Student.collegeName);
	}
}
