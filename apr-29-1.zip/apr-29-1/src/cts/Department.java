package cts;

public class Department {

}
