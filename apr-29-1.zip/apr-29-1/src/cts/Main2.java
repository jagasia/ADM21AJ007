package cts;
import cts.Employee;

public class Main2 {

	public static void main(String[] args) {
		cts.Employee rama=new Employee();
		rama.employeeId=100;		//public so available
		//rama.salary=210000;			//private so not available
		rama.name="Rama";			//protected so available
		rama.phoneNo="90909090";	//default so available
	}

}
