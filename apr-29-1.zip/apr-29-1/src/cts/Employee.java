package cts;

public class Employee {
	public int employeeId;
	private float salary;
	protected String name;
	String phoneNo;

}
