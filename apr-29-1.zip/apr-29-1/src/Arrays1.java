import java.util.Arrays;
import java.util.Scanner;

public class Arrays1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int [][]arr= {
				{100,200,300,500,900,1010},
				{55,66},
				{1,3,5,6,7,8,9}
		};
		
		for(int i=0;i<arr.length;i++)
		{			
			for(int j=0;j<arr[i].length;j++)
			{
				System.out.print(arr[i][j]+"\t");
			}
			System.out.println();
		}
	}

}
