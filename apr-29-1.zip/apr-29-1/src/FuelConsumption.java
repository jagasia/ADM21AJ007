import java.util.Scanner;

public class FuelConsumption {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of liters to fill the tank");
		float litres=sc.nextFloat();
		if(litres<0)
		{
			System.out.println(litres+"is an Invalid Input");
			System.exit(0);
		}
		System.out.println("Enter the distance covered");
		float distance=sc.nextFloat();
		if(distance<0)
		{
			System.out.println(distance+"is an Invalid Input");
			System.exit(0);
		}
		float galons=litres*0.2642f;
		float miles=distance*0.6214f;
		
		//find liters/100 km
		float result1=(litres/distance)*100;
		System.out.printf("Liters/100KM\n%.2f\n",result1);
		
		float result2=miles/galons;
		System.out.printf("Miles/gallons\n%.2f\n",result2);
	}

}
