class Person
{
	String name;		//instance variable
	static String country;	//static variable
	public void display()
	{
		System.out.println(name);
		System.out.println(country);
	}
}
public class Example3 {

	public static void main(String[] args) {
		
	}
}
