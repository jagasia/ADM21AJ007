import java.util.Scanner;

public class Task3 {
	public static void main(String[] args) {
		int no1, no2;
		Scanner sc=new Scanner(System.in);
		no1=sc.nextInt();
		no2=sc.nextInt();
		if(no1<0 ||no1>6 ||no2<0 ||no2>6)
		{
			System.out.println("Invalid Input");
			System.exit(0);
		}
		int sum=no1+no2;
		if(no1==no2)
			sum*=2;
		System.out.println("The points scored is "+sum);
	}
}
