import java.util.Scanner;

public class BookShelf extends Furniture{
	int noOfShelves;

	@Override
	public void acceptDetails() {
		// TODO Auto-generated method stub
		super.acceptDetails();
		Scanner sc=new Scanner(System.in);
		System.out.println("No of shelves:");
		noOfShelves = sc.nextInt();
	}

	@Override
	public void displayDetails() {
		// TODO Auto-generated method stub
		super.displayDetails();
		System.out.println("No of shelves:"+noOfShelves);
	}
	
}
