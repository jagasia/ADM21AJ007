import java.util.Scanner;

public class Main_Furniture {

	public static void main(String[] args) {
		Furniture f=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("\r\n" + 
				"1: Chair\r\n" + 
				"2: Book Shelf\r\n" + 
				"");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			f=new Chair();
			break;
		case 2:
			f=new BookShelf();
			break;		
		}
		f.acceptDetails();
		f.displayDetails();
	}

}
