import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		//loop every character to check if it is vowel or not
		String copy=input.toLowerCase();
		for(int i=0;i<copy.length();i++)
		{
			char c=copy.charAt(i);
			switch(c)
			{
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				System.out.print(c);
			break;
			}
		}
	}

}
