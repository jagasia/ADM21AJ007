class Employee
{
	{
		System.out.println("This is a block");
	}
	
	static
	{
		System.out.println("This is static block");
	}
}
public class Example2 {
	static
	{
		System.out.println("this is static block of Example 2 class");
	}
	public static void main(String[] args) {
		System.out.println("hello world");
		Employee siva;
		siva=new Employee();
		Employee rama=new Employee();
	}

}
