import java.util.ArrayList;
import java.util.Collections;

public class Main3 {

	public static void main(String[] args) {
		ArrayList<Integer> marks=new ArrayList<>();
		marks.add(90);
		marks.add(100);
		marks.add(50);
		marks.add(60);
		//sort the collection 
		Collections.sort(marks);
		for(Integer x:marks)
			System.out.println(x);
	}

}
