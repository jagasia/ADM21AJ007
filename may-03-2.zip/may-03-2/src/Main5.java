import java.util.HashSet;
import java.util.Set;

public class Main5 {

	public static void main(String[] args) {
		Set<Employee> employeeSet=new HashSet<>();
		employeeSet.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeSet.add(new Employee(7, "Suresh", "Kumar", 1234567.0));
		employeeSet.add(new Employee(1, "Ram", "Lakshman", 1234567.0));
		employeeSet.add(new Employee(8, "Ram", "Kumaresan", 1234567.0));		
		employeeSet.add(new Employee(2, "Siva", "Kumar", 84383.0));
		employeeSet.add(new Employee(3, "Rama", "Krishna", 747474.0));
		employeeSet.add(new Employee(1, "Siva", "Raja", 383838.0));
		employeeSet.add(new Employee(5, "Rama", "Nathan", 199111.0));
		employeeSet.add(new Employee(1, "John", "Kennedy", 1024567.0));
		
		for(Employee e:employeeSet)
			System.out.println(e);
	}

}
