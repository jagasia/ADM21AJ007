import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Main1 {

	public static void main(String[] args) {
//		ArrayList<Integer> marks=new ArrayList<>();
		List<Integer> marks=new ArrayList<>();
		marks.add(90);
		marks.add(100);
		marks.add(90);
		marks.add(50);
		marks.add(60);
		//we can add lot of elements but no need to specirfy the size
//		for(Integer x:marks)
//			System.out.println(x);
		
//		for(int i=0;i<marks.size();i++)
//			System.out.println(marks.get(i));
		
		//use iterators for accessing all the elements
//		Iterator<Integer> it = marks.iterator();
		ListIterator<Integer> it = marks.listIterator();
		while(it.hasNext())
		{
			Integer x = it.next();
			System.out.println(x +" is the current value");
		}
		System.out.println("Now, traversing in reverse direction");
		while(it.hasPrevious())
		{
			Integer x = it.previous();
			System.out.println(x);
		}
	}

}
