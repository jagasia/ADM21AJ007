import java.util.HashSet;

public class Main2 {

	public static void main(String[] args) {
		HashSet<Integer> marks=new HashSet<>();
		marks.add(90);
		marks.add(100);
		marks.add(90);
		marks.add(50);
		marks.add(90);
		marks.add(90);
		marks.add(60);
		marks.remove(50);
		//we can add lot of elements but no need to specirfy the size
		System.out.println(marks);

	}

}
