import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String source, destination;
		System.out.println("Enter the source");
		source=sc.next();
		System.out.println("Enter the destination");
		destination=sc.next();
		
	}

}
