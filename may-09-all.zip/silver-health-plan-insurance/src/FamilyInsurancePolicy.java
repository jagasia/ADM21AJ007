
public class FamilyInsurancePolicy extends InsurancePolicies
{

	public FamilyInsurancePolicy(String clientName, String policyId, int age, long mobileNumber, String emailId) {
		super(clientName, policyId, age, mobileNumber, emailId);
		// TODO Auto-generated constructor stub
	}
	public boolean validatePolicyId()
	{
		String policyId=getPolicyId();
		return policyId.matches("(FAMILY){1}[0-9]{3}");
	}
	public double calculateInsuranceAmount(int months, int no_of_members)
	{
		//5		to 25	2500
		//26	to 59	5000
		//60 and above 	1000
		int age=getAge();
		long amount_based_on_policyAndAge=0;
		
		if(age>=5 && age<=25)
			amount_based_on_policyAndAge=2500;
		else if(age>=26 && age<=59)
			amount_based_on_policyAndAge=5000;
		else if(age>=60)
			amount_based_on_policyAndAge=10000;
			
		double amount =amount_based_on_policyAndAge * months * no_of_members;
		return amount;
	}
}
