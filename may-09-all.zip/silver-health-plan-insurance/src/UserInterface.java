import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Client name");
		String clientName=sc.next();
		System.out.println("Enter Policy Id");
		String policyId=sc.next();
		System.out.println("Enter Client age");
		int age=sc.nextInt();
		System.out.println("Enter mobile number");
		long mobileNumber=sc.nextLong();
		System.out.println("Enter Email Id");
		String emailId=sc.next();
		System.out.println("Enter the months");
		int months=sc.nextInt();
		//check if the policy is individual
		IndividualInsurancePolicies individual=new IndividualInsurancePolicies(clientName, policyId, age, mobileNumber, emailId);
		if(individual.validatePolicyId())
		{
			//yes individual
			System.out.println("Name :"+individual.getClientName());
			System.out.println("Email Id :"+individual.getEmailId());
			System.out.println("Amount to be paid :"+individual.calculateInsuranceAmount(months));
		}
		else
		{
			//check if the policy is family
			FamilyInsurancePolicy family=new FamilyInsurancePolicy(clientName, policyId, age, mobileNumber, emailId);
			if(family.validatePolicyId())
			{
				//yes family
				System.out.println("Enter number of members");
				int no_of_members=sc.nextInt();
				System.out.println("Name :"+family.getClientName());
				System.out.println("Email Id :"+family.getEmailId());
				System.out.println("Amount to be paid :"+family.calculateInsuranceAmount(months, no_of_members));
			}else
			{
				//check if the policy is senior
				SeniorCitizenPolicy senior=new SeniorCitizenPolicy(clientName, policyId, age, mobileNumber, emailId);
				if(senior.validatePolicyId())
				{
					//yes senior
					System.out.println("Enter number of members");
					int no_of_members=sc.nextInt();
					System.out.println("Name :"+senior.getClientName());
					System.out.println("Email Id :"+senior.getEmailId());
					System.out.println("Amount to be paid :"+senior.calculateInsuranceAmount(months, no_of_members));
				}else
				{
					//invalid policy id
					System.out.println("Provide valid Policy Id");
					return;
				}
			}
		}
		
		
	}

}
