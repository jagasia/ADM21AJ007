
public class SeniorCitizenPolicy extends InsurancePolicies
{

	public SeniorCitizenPolicy(String clientName, String policyId, int age, long mobileNumber, String emailId) {
		super(clientName, policyId, age, mobileNumber, emailId);
		// TODO Auto-generated constructor stub
	}
	public boolean validatePolicyId()
	{
		String policyId=getPolicyId();
		return policyId.matches("(SENIOR){1}[0-9]{3}");
	}
	public double calculateInsuranceAmount(int months, int no_of_members)
	{		
		long amount_based_on_policyAndAge=10000;
//		amount_based_on_policyAndAge=10000;
		double amount =amount_based_on_policyAndAge * months * no_of_members;
		return amount;
	}
}
