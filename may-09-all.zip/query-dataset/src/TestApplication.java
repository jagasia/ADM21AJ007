import java.util.Scanner;



public class TestApplication {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String queryId;
		String queryCategory;
		String theatreId;
		String theatreName;
		String location;
		int noOfScreen;
		double ticketCost;
		
		Query query=new Query();
		System.out.println("Enter the Details for primary data set");
		System.out.println("Enter the theatre id");
		theatreId=sc.next();
		System.out.println("Enter the theatre name");
		theatreName=sc.nextLine();
		if(theatreName.equals(""))
			theatreName=sc.nextLine();
		System.out.println("Enter the location");
		location=sc.next();
		System.out.println("Enter the no of screens");
		noOfScreen=sc.nextInt();
		System.out.println("Enter the ticket cost");
		ticketCost=sc.nextDouble();
		query.getPrimaryDataSet().setTheatreId(theatreId);
		query.getPrimaryDataSet().setTheatreName(theatreName);
		query.getPrimaryDataSet().setLocation(location);
		query.getPrimaryDataSet().setNoOfScreen(noOfScreen);
		query.getPrimaryDataSet().setTicketCost(ticketCost);
//-------------------
		System.out.println("Enter the Details for secondary data set");
		System.out.println("Enter the theatre id");
		theatreId=sc.next();
		System.out.println("Enter the theatre name");
		theatreName=sc.next();
		System.out.println("Enter the location");
		location=sc.next();
		System.out.println("Enter the no of screens");
		noOfScreen=sc.nextInt();
		System.out.println("Enter the ticket cost");
		ticketCost=sc.nextDouble();
		query.getSecondaryDataSet().setTheatreId(theatreId);
		query.getSecondaryDataSet().setTheatreName(theatreName);
		query.getSecondaryDataSet().setLocation(location);
		query.getSecondaryDataSet().setNoOfScreen(noOfScreen);
		query.getSecondaryDataSet().setTicketCost(ticketCost);
		System.out.println("Enter the query id");
		queryId=sc.next();
		query.setQueryId(queryId);
		System.out.println("Enter the query category");
		queryCategory=sc.next();
		query.setQueryCategory(queryCategory);
		System.out.println(query);
	}
}
