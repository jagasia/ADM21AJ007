
public class Query {
	private String queryId;
	private String queryCategory;
	private DataSet primaryDataSet;
	private DataSet secondaryDataSet;
	public Query()
	{
		primaryDataSet=new DataSet();
		secondaryDataSet=new DataSet();
	}
	public String getQueryId() {
		return queryId;
	}
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}
	public String getQueryCategory() {
		return queryCategory;
	}
	public void setQueryCategory(String queryCategory) {
		this.queryCategory = queryCategory;
	}
	public DataSet getPrimaryDataSet() {
		return primaryDataSet;
	}
	public void setPrimaryDataSet(DataSet primaryDataSet) {
		this.primaryDataSet = primaryDataSet;
	}
	public DataSet getSecondaryDataSet() {
		return secondaryDataSet;
	}
	public void setSecondaryDataSet(DataSet secondaryDataSet) {
		this.secondaryDataSet = secondaryDataSet;
	}
	

@Override
	public String toString() {
	String output=String.format("Primary data set\n" + 
			"Theatre id : %s\n" + 
			"Theatre name : %s\n" + 
			"Location : %s\n" + 
			"No of Screen : %d\n" + 
			"Ticket Cost : %.0f\n" + 
			"Secondary data set\n" + 
			"Theatre id : %s\n" + 
			"Theatre name : %s\n" + 
			"Location : %s\n" + 
			"No of Screen : %d\n" + 
			"Ticket Cost : %.0f\n" + 
			"Query id : %s\n" + 
			"Query category : %s\n",primaryDataSet.getTheatreId(), primaryDataSet.getTheatreName(),primaryDataSet.getLocation(),primaryDataSet.getNoOfScreen(),primaryDataSet.getTicketCost(),secondaryDataSet.getTheatreId(), secondaryDataSet.getTheatreName(),secondaryDataSet.getLocation(),secondaryDataSet.getNoOfScreen(),secondaryDataSet.getTicketCost(),queryId, queryCategory);
	return output;
	}


class DataSet {
	private String theatreId;
	private String theatreName;
	private String location;
	private int noOfScreen;
	private double ticketCost;
	public String getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getNoOfScreen() {
		return noOfScreen;
	}
	public void setNoOfScreen(int noOfScreen) {
		this.noOfScreen = noOfScreen;
	}
	public double getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}
	
}

}
