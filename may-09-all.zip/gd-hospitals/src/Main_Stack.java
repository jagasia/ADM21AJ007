import java.util.Stack;

public class Main_Stack {

	public static void main(String[] args) {
		Stack<String> stack=new Stack<>();
		Stack<String> seats=new Stack<>();
		
		stack.push("A");
		seats.push("1");
		stack.push("B");
		seats.push("2");
		stack.push("C");
		seats.push("3");
		stack.push("D");
		seats.push("4");
		stack.push("E");
		seats.push("5");
		stack.push("F");
		seats.push("6");
		stack.push("G");
		seats.push("7");
		stack.push("H");
		seats.push("8");
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
		System.out.print(stack.pop());
		System.out.println(seats.pop());
	}
}
