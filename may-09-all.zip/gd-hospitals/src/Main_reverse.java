
public class Main_reverse {
	public static void main(String[] args) {
		String str="management";
		StringBuilder sb=new StringBuilder(str);
		String result=sb.reverse().toString();
		System.out.println(result);
	}
}
