
public class InPatient extends Patient{
	private double roomRent;

	public InPatient(String patientId, String patientName, long mobileNumber, String gender, double roomRent) {
		super(patientId, patientName, mobileNumber, gender);
		this.roomRent=roomRent;
	}

	public double getRoomRent() {
		return roomRent;
	}

	public void setRoomRent(double roomRent) {
		this.roomRent = roomRent;
	}
	
	public double calculateTotalBill(int noOfDays,double medicinalBill)
	{
//		Bill Amount=roomRent*noOfDays+medicinalBill
		//pending
		double billAmount=roomRent*noOfDays+medicinalBill;
		return billAmount;
	}
}
