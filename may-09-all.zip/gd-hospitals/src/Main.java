import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("1.In Patient\r\n" + 
				"2.Out Patient\r\n" + 
				"Enter the choice");
		int choice=sc.nextInt();
		String patientId;
		String patientName;
		long mobileNumber;
		String gender;
		System.out.println("Enter the details");
		System.out.println("Patient Id");
		patientId=sc.next();
		System.out.println("Patient Name");
		patientName=sc.next();
		System.out.println("Phone Number");
		mobileNumber=sc.nextLong();
		System.out.println("Gender");
		gender=sc.next();
		double result=0.0;
		double medicinalBill=0.0;
		switch(choice)
		{
		case 1:	//in patient
			System.out.println("Room Rent");
			double roomRent=sc.nextDouble();
			System.out.println("Medicinal Bill");
			medicinalBill=sc.nextDouble();
			System.out.println("Number of Days of Stay");
			int noOfDays=sc.nextInt();
			InPatient ip=new InPatient(patientId, patientName, mobileNumber, gender, roomRent);
			result = ip.calculateTotalBill(noOfDays, medicinalBill);
			break;
		case 2:	//out patient
			System.out.println("Consultancy Fee");
			double consultingFee=sc.nextDouble();
			System.out.println("Medicinal Bill");
			medicinalBill=sc.nextDouble();
			System.out.println("Scan Pay");
			double scanPay=sc.nextDouble();
			OutPatient op=new OutPatient(patientId, patientName, mobileNumber, gender, consultingFee);
			result=op.calculateTotalBill(scanPay, medicinalBill);
			break;
		}
		System.out.println("Amount to be paid "+result);

	}

}
