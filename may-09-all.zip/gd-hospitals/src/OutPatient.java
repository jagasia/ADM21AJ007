
public class OutPatient extends Patient{
	private double consultingFee;

	public OutPatient(String patientId, String patientName, long mobileNumber, String gender, double consultingFee) {
		super(patientId, patientName, mobileNumber, gender);
		this.consultingFee=consultingFee;
	}

	public double getConsultingFee() {
		return consultingFee;
	}

	public void setConsultingFee(double consultingFee) {
		this.consultingFee = consultingFee;
	}

	public double calculateTotalBill(double scanPay,double medicinalBill)
	{
//		Bill Amount= consultingFee+scanPay+medicinalBill
		//pending
		double billAmount=consultingFee+scanPay+medicinalBill;
		return billAmount;
	}
}
