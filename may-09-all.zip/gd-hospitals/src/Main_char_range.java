
public class Main_char_range {

	public static void main(String[] args) {
		String str="A1";
		char c=str.charAt(0);
		if(c>='A' && c<='Z')
			System.out.println("Capital letters");
		else
			System.out.println("Not cap");
	}

}
