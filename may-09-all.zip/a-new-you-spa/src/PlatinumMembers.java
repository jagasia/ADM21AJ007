
public class PlatinumMembers extends Members{

	
	public PlatinumMembers(String customerId, String customerName, long mobileNumber, String memberType,
			String emailId) {
		super(customerId, customerName, mobileNumber, memberType, emailId);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculateDiscount(double purchaseAmount) {
		//30%
		double discount = purchaseAmount*30/100;
		return purchaseAmount-discount;
	}
	
	public boolean validateCustomerId()
	{
		return getCustomerId().matches("(PLATINUM){1}\\d{3}");
	}

}
