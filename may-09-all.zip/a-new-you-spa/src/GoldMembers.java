
public class GoldMembers extends Members{

	
	public GoldMembers(String customerId, String customerName, long mobileNumber, String memberType, String emailId) {
		super(customerId, customerName, mobileNumber, memberType, emailId);
		
	}

	@Override
	public double calculateDiscount(double purchaseAmount) {
		//15%
		double discount = purchaseAmount*15/100;
		return purchaseAmount-discount;
	}
	public boolean validateCustomerId()
	{
		return getCustomerId().matches("(GOLD){1}[0-9]{3}");
	}
	

//	public boolean validateCustomerId()
//	{
//		String cid=getCustomerId();
//		
//		if(cid.length()!=7)
//			return false;
//		if(!cid.subSequence(0, 4).equals("GOLD"))
//			return false;
//		String digits=cid.substring(4,7);
//		int num=0;
//		try {
//		num=Integer.parseInt(digits);
//		}catch(NumberFormatException nfe)
//		{
//			return false;
//		}
//		return true;
//	}
//	public static void main(String[] args) {
//		String str="GOLD123";
//		System.out.println(str.matches("(GOLD){1}[0-9]{3}"));
//		
//	}
}
