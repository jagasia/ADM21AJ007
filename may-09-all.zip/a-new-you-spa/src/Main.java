import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		String customerId;
		String customerName;
		long mobileNumber;
		String memberType;
		String emailId;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Customer Id");
		customerId=sc.next();
		System.out.println("Enter Customer name");
		customerName=sc.next();
		System.out.println("Enter mobile number");
		mobileNumber=sc.nextLong();
		System.out.println("Enter Member type");
		memberType=sc.next();
		System.out.println("Enter Email Id");
		emailId=sc.next();
		System.out.println("Enter amount Purchased");
		double purchaseAmount=sc.nextDouble();
		double billAmount=0.0;
		
		switch (memberType) {
		case "Gold":
			GoldMembers goldMembers=new GoldMembers(customerId, customerName, mobileNumber, memberType, emailId);
		
			if(goldMembers.validateCustomerId())
			{
				System.out.println("Name :"+goldMembers.getCustomerName());
				System.out.println("Id :"+goldMembers.getCustomerId());
				System.out.println("Email Id :"+goldMembers.getEmailId());
				billAmount=goldMembers.calculateDiscount(purchaseAmount);
				System.out.println("Amount to be paid :"+billAmount);
			}else
				System.out.println("Provide a valid Customer Id");
			break;
		case "Platinum":
			PlatinumMembers platinumMembers=new PlatinumMembers(customerId, customerName, mobileNumber, memberType, emailId);
			
			if(platinumMembers.validateCustomerId())
			{
				System.out.println("Name :"+platinumMembers.getCustomerName());
				System.out.println("Id :"+platinumMembers.getCustomerId());
				System.out.println("Email Id :"+platinumMembers.getEmailId());
				billAmount=platinumMembers.calculateDiscount(purchaseAmount);
				System.out.println("Amount to be paid :"+billAmount);
			}else
				System.out.println("Provide a valid Customer Id");
			break;
		case "Diamond":
			DiamondMembers diamondMembers=new DiamondMembers(customerId, customerName, mobileNumber, memberType, emailId);
			
			if(diamondMembers.validateCustomerId())
			{
				System.out.println("Name :"+diamondMembers.getCustomerName());
				System.out.println("Id :"+diamondMembers.getCustomerId());
				System.out.println("Email Id :"+diamondMembers.getEmailId());
				billAmount=diamondMembers.calculateDiscount(purchaseAmount);
				System.out.println("Amount to be paid :"+billAmount);
			}else
				System.out.println("Provide a valid Customer Id");
			break;
		}
		
	
	}

}
