
public class DiamondMembers extends Members
{
	public DiamondMembers(String customerId, String customerName, long mobileNumber, String memberType,
			String emailId) {
		super(customerId, customerName, mobileNumber, memberType, emailId);
		// TODO Auto-generated constructor stub
	}
	@Override
	public double calculateDiscount(double purchaseAmount) {
		//45%
		double discount = purchaseAmount*45/100;
		return purchaseAmount-discount;
	}
	public boolean validateCustomerId()
	{
		return getCustomerId().matches("(DIAMOND){1}[0-9]{3}");
	}
}
