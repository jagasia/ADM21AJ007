class InvalidAmountException extends NumberFormatException
{
	public InvalidAmountException()
	{}
	public InvalidAmountException(String message)
	{
		super(message);
	}
}

class Bank
{
	public void withdraw(int amount) 
	{
		if(amount<30000)
			System.out.println("Remember to collect cash");
		else
			throw new InvalidAmountException("amount cannot be greater than 30k");
	}
}

public class ExceptionDemo2 {

	public static void main(String[] args) {
		Bank sbi=new Bank();
//		try {
			sbi.withdraw(20000);
//		} catch (InvalidAmountException e) {
//			System.out.println(e.getMessage());
//		}
	}

}
