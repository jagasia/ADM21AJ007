abstract class Shape
{
	String name, color, backgroundColor;
	public abstract void calculateArea();
	public void draw()
	{
		System.out.println("Drawing the shape now");
	}
}
class Pentagon extends Shape
{
	public void calculateArea() {
		
	}
}
class Circle extends Shape
{
	public void calculateArea()
	{
		System.out.println("3.14f * radius * radius");
	}
}
class Triangle extends Shape
{
	public void calculateArea()
	{
		System.out.println("0.5f * breadth * height");
	}
}
public class App2 {

	public static void main(String[] args) {
		Shape s;
		s=new Circle();
		s.name="circle";
		s.calculateArea();
		
		s=new Triangle();
		s.calculateArea();
	}

}
