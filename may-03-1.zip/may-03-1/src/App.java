class Arithmetic
{
	public int sum(int i, int j)
	{
		return i+j;
	}
	
	public String sum(String s1, String s2)
	{
		return s1+s2;
	}
}


public class App {

	public static void main(String[] args) {
		System.out.println("Hello world");
		Arithmetic a=new Arithmetic();
		System.out.println(a.sum(2, 3));
		System.out.println(a.sum("Rama", "Krishna"));
	}

}
