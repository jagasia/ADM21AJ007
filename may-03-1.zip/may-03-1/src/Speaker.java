
public interface Speaker 
{
	void playSong();
	public static final int AGE=20;
	float TAX=12.36f;
}
