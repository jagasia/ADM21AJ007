interface Jack
{
	public void playSound();
	float SIZE=3.5f;
}

class Sony implements Jack
{
	@Override
	public void playSound() {
		System.out.println("Sony head phone is playing song");
	}	
}
class JBL implements Jack
{
	public void playSound() {
		System.out.println("JBL Playing music");
	}
}

class Mobile
{
	public void audio(Jack jack)
	{
		jack.playSound();
	}
	public void audio(BluetoothHeadPhone b)
	{
		b.playSound();
	}
}

class BluetoothHeadPhone
{
	public void playSound()
	{
		System.out.println("Bluetooth sound");
	}
}
public class App3 {
	public static void main(String[] args) {
		Mobile redmi=new Mobile();
//		Sony sony=new Sony();
//		JBL jbl=new JBL();
		BluetoothHeadPhone btp=new BluetoothHeadPhone();
		redmi.audio(btp);
	}
}
