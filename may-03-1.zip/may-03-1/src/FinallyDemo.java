

public class FinallyDemo {
	public static void main(String[] args) {
		int i=20;
		int j=30;
		j-=20;
		try
		{
			if(j==10)
				throw new ArrayIndexOutOfBoundsException("This is thrown by me");
			System.out.println("Going to divide");
			int k=i/j;
			System.out.println(k);
		}catch(ArrayIndexOutOfBoundsException ae)
		{
			System.out.println(ae.getMessage());
		}
//		catch(ArithmeticException ae)
//		{
//			System.out.println(ae.getMessage());
//		}
//		catch(Exception ex)
//		{
//			System.out.println(ex.getMessage());
//		}
		finally
		{
			System.out.println("This is finally");
		}
		System.out.println("The program continues");
	}
}
