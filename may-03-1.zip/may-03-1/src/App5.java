class Employee
{
	
}
class ContractEmployee extends Employee
{
	
}
public class App5 {

	public static void main(String[] args) {
		Employee e=new ContractEmployee();		//implicit casting
		ContractEmployee ce=(ContractEmployee) e;//explicit casting
		
	}

}
