interface Person
{
	public void speak();
	default void run()
	{
		System.out.println("This is default behavior of a person running");
	}
	static void walk()
	{
		System.out.println("A person walks");
	}
}

class Student implements Person
{
	public void run()
	{
		System.out.println("Student runs");
	}
	public void walk()
	{
		System.out.println("Student walks");
	}
	@Override
	public void speak() {
		System.out.println("Student speaks");
		
	}
	
}

public class App4 {

	public static void main(String[] args) {
//		Person.walk();
		Person rama=new Student();
//		rama.walk();
		rama.run();
		
		
	}

}
