package com.cts.hms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.cts.hms.entity.Cart;
import com.cts.hms.entity.Customer;
import com.cts.hms.entity.Product;
import com.cts.hms.service.CustomerService;
import com.cts.hms.service.ProductService;

@Component
public class CartRowMapper implements RowMapper<Cart>{
	
	@Override
	public Cart mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new Cart(rs.getLong(1),rs.getLong(2),rs.getLong(3));
	}

}
