package com.cts.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.entity.Cart;
import com.cts.hms.entity.Customer;
import com.cts.hms.entity.Product;
import com.cts.hms.service.CartService;
import com.cts.hms.service.CustomerService;
import com.cts.hms.service.ProductService;

@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class CartController {
	@Autowired
	private CartService cs;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ProductService ps;
	
	private Long generateCartId()
	{
		List<Cart> carts = getAllCarts();
		if(carts.size()==0)
		{
			return 1L;
		}
		Long lastIndex=carts.get(carts.size()-1).getId();
		return lastIndex+1;
	}
	
	@PostMapping("/cart/{cid}/{pid}")
	public int add2Cart(@PathVariable("cid") Long customerId, @PathVariable("pid") Long productId)
	{
		Customer customer=customerService.read(customerId);
		Product product=ps.read(productId);
		Long id=generateCartId();
		Cart cart=new Cart(id, customerId, productId);
		cart.setId(id);
		System.out.println("Cart Controller: 38th line: "+cart);
		
		return cs.create(cart);
	}
	
	@GetMapping("/cart")
	public List<Cart> getAllCarts()
	{
		return cs.read();
	}
	
	@GetMapping("/cart/customer/{id}")
	public List<Cart> findCartItemsByCustomerId(@PathVariable Long id)
	{
		return cs.findCartItemsByCustomerId(id);
	}
	
	@GetMapping("/cart/{id}")
	public Cart findCartById(@PathVariable Long id)
	{
		return cs.read(id);
	}
	
	
	@PutMapping("/cart")
	public int modifyCart(@RequestBody Cart cart)
	{
		return cs.update(cart);
	}
	
	@DeleteMapping("/cart/{id}")
	public int removeCart(@PathVariable Long id)
	{
		return cs.delete(id);
	}
}
