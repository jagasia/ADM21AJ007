package com.cts.hms.entity;

public class Cart {
	private Long id;
	private Long customerId;
	private Long productId;

	public Cart() {}

	public Cart(Long id, Long customerId, Long productId) {
		super();
		this.id = id;
		this.customerId = customerId;
		this.productId = productId;
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "Cart [id=" + id + ", customerId=" + customerId + ", productId=" + productId + "]";
	}
	
}
