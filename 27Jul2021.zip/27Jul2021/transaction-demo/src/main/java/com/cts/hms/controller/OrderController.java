package com.cts.hms.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.hms.entity.Order;
import com.cts.hms.service.OrderService;

@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class OrderController {
	@Autowired
	private OrderService cs;
	
	@PostMapping("/order")
	public int addOrder(@RequestBody Order order)
	{
		order.setId(generateOrderId());
		return cs.create(order);
	}
	
	@GetMapping("/order")
	public List<Order> getAllOrders()
	{
		return cs.read();
	}
	
	@GetMapping("/order/{id}")
	public Order findOrderById(@PathVariable Long id)
	{
		return cs.read(id);
	}
	
	@GetMapping("/order/customer/{id}")
	public List<Order> findOrdersByCustomer(@PathVariable Long id)
	{
		return cs.findOrdersByCustomer(id);
	}
	
	private Long generateOrderId()
	{
		List<Order> orders = getAllOrders();
		Collections.sort(orders,(a,b)->a.getId().compareTo(b.getId()));
		if(orders.size()==0)
			return 1L;
		Order lastOrder = orders.get(orders.size());
		Long id=0L;
		if(lastOrder!=null)
			id=lastOrder.getId();
		id++;
		return id;
	}
	
	@PutMapping("/order")
	public int modifyOrder(@RequestBody Order order)
	{
		return cs.update(order);
	}
	
	@DeleteMapping("/order/{id}")
	public int removeOrder(@PathVariable Long id)
	{
		return cs.delete(id);
	}
}
