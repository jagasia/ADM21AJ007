import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  productForm:any;
  products:any;
  categories:any;
  constructor(private fb:FormBuilder, private ps:ProductService) {
    this.productForm=this.fb.group({
      id:[],
      name:[],
      category:[''],
      price:[]
    });
   }

  ngOnInit(): void {
    //get all categories from service
    this.ps.getCategories().subscribe((data)=>{
      console.log(data);
      this.categories=data;
    });
    //get all products from service
    this.ps.getAllProducts().subscribe((data)=>this.products=data);
  }

  fnAdd(){
    var product=this.productForm.value;
    console.log('sending the below object to rest api');
    console.log(product);
    this.ps.addProduct(product).subscribe((data)=>{
      console.log(data);
    });
  }
  fnModify(){
    var product=this.productForm.value;
    console.log('sending the below object to rest api');
    console.log(product);
    this.ps.modifyProduct(product).subscribe((data)=>{
      console.log(data);
    });
  }
  fnRemove(){
    var id=this.productForm.controls['id'].value;
    console.log("Removing product of id "+id);
    this.ps.removeProduct(id).subscribe(data=>console.log(data));
  }
}
