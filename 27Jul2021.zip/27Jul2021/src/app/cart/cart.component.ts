import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems:any;
  customer:any;
  constructor(private cartService:CartService) { }

  ngOnInit(): void {
    var c=localStorage.getItem("customer");
    if(c==null || c=='')
    {
      alert('You have not logged in....');
      return;
    }
    //logged in user....
    this.customer=JSON.parse(c);
    
    this.cartService.getCartItemsByCustomerId(this.customer.id).subscribe((data)=>{
      console.log(data);
      this.cartItems=data;
    });
  }

  fnRemove(id:any)
  {
      // alert("Removing "+id);
      this.cartService.removeFromCart(id).subscribe((data)=>{
        console.log(data);
      })
  }

}
