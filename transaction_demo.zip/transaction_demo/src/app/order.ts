export class Order {
    // private Long id;
	// private Date orderDate;
	// private Long productId;
	// private Long customerId;
	// private Long quantity;
    id:number=0;
    orderDate:Date=new Date();
    productId:number=0;
    customerId:number=0;
    quantity:number=1;
}
