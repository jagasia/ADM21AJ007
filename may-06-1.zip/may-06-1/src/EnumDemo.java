enum Days{	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY }


public class EnumDemo {
	

	public static void main(String[] args) {
		Days d=Days.MONDAY;
		System.out.println(d.ordinal());
	}

}
