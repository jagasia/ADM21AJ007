import java.io.File;
import java.io.IOException;

public class Main1 {

	public static void main(String[] args) throws IOException {
		File f=new File("D:\\jag\\sahil");
		//create a file if it is not present
//		System.out.println(f.exists());
		if(!f.exists())
		{
//			f.createNewFile();
//			System.out.println("Created the file:"+f.getAbsolutePath());
			if(f.mkdir())
				System.out.println("Created folder:"+f.getAbsolutePath());
			else
				System.out.println("Couldn't create");
		}
		
	}

}
