import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;

class Student implements Serializable
{
	private int id;
	private String name;
	private float marks;
	private transient int age;	//not included in serialization. value of age is not stored in stream
	transient	SimpleDateFormat sdf;
	volatile int i=20;			//thread safe		threads usually keep a copy of variable in their cache. volatile variables will not be kept in thread cache
	
	public Student() {}

	public Student(int id, String name, float marks) {
		super();
		this.id = id;
		this.name = name;
		this.marks = marks;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getMarks() {
		return marks;
	}

	public void setMarks(float marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", marks=" + marks + "]";
	}
	
}

public class ObjectDemo {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
//		Student student=new Student(100, "Raja", 9.5f);
//		//store this student object into the file
//		FileOutputStream fos=new FileOutputStream("d:\\jag\\sahil\\harish.dat");
//		ObjectOutputStream oos=new ObjectOutputStream(fos);
//		oos.writeObject(student);
//		oos.flush();
//		oos.close();
		
		//read object from the file
		FileInputStream fis=new FileInputStream("d:\\jag\\sahil\\harish.dat");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Student x = (Student) ois.readObject();
		System.out.println(x);
		System.out.println("Check");
	}

}
