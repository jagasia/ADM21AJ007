import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Image_demo {

	public static void main(String[] args) throws IOException {
		File source=new File("C:\\Users\\rjaga\\Pictures\\pendrive.jpg");
		//to read all bytes from the file
		FileInputStream fis=new FileInputStream(source);
		//to read the bytes and keep it, we need an array
		//what should be the size of the byte array?
		byte []data=new byte[(int) source.length()];
		fis.read(data);
		fis.close();
		//------------------------
		FileOutputStream fos=new FileOutputStream("d:\\jag\\sahil\\pratik.jpg");
		//fos can create the file while writing bytes. no need to create file 
		fos.write(data);
		fos.close();
		System.out.println("File is created at d:\\\\jag\\\\sahil\\\\pratik.jpg");
	}

}
