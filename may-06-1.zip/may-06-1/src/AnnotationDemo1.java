
public class AnnotationDemo1 {

	@Deprecated
	public static void display()
	{
		System.out.println("Display method is called");
	}
	public static void show()
	{
		System.out.println("This is show method");
	}
	public static void main(String[] args) {
		display();
		show();
	}

}
