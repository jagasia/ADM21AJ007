import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class imagea_demo_sync {

	public static void main(String[] args) throws IOException, InterruptedException{
		File source=new File("C:\\Users\\rjaga\\Pictures\\Logo3.jpg");		
		FileInputStream fis=new FileInputStream(source);
		FileOutputStream fos=new FileOutputStream("d:\\jag\\sahil\\anurag.jpg");
		int i=-1;
		while((i=fis.read())!=-1)
		{
			fos.write(i);
			fos.flush();
//			Thread.sleep(10);
		}
		System.out.println("Check");
		fos.close();
	}

}
