
public class AssertionDemo {

	public static void main(String[] args) {
		int i=140;
		int j=130;
		assert i>j;
		System.out.println("The program ends gracefully");
	}
}
