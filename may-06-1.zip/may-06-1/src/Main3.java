import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

public class Main3 {

	public static void main(String[] args) {
		Method[] methods = Main2.class.getMethods();
		for(Method m:methods)
		{
			if(m.getAnnotations().length>0)
			{
				System.out.println(m.getName());
				System.out.println("Displaying annotations of this method");
				for(Annotation a:m.getAnnotations())
					System.out.println("-------"+a.toString());
			}
		}
	}

}
