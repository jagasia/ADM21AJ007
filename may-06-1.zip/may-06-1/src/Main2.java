@JagAnnotation(name = "Jag")
public class Main2 {

	@MyAnnotation
	public static void display()
	{
		System.out.println("THis is display method");
	}
	
	public static void main(String[] args) {
		display();
	}

}
