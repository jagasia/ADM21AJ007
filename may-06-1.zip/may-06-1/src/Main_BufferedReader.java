import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main_BufferedReader {

	public static void main(String[] args) throws IOException {		
//		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
//		String str=br.readLine();
//		System.out.println("You entered:");
//		System.out.println(str);
//		BufferedInputStream bis=new BufferedInputStream(System.in);
		//read bytes using bis
//		FileWriter fw=new FileWriter("d:\\jag\\sahil\\rajesh.txt");
//		fw.write("India is our country. It is in Asia");
//		fw.flush();		//from memory the data is pushed to storage
//		fw.close(); 	//close also calls flush()	when process terminates gracefully, close() is automatically called
		
//		FileOutputStream fos=new FileOutputStream("d:\\jag\\sahil\\bharatwaj.dat");
//		DataOutputStream dos=new DataOutputStream(fos);
//		dos.write(20);
//		dos.writeFloat(1.5f);
//		dos.writeChars("Hello");
//		dos.flush();
//		dos.close();
		FileInputStream fis=new FileInputStream("d:\\jag\\sahil\\bharatwaj.dat");
		DataInputStream dis=new DataInputStream(fis);
		int i=dis.read();
		float f=dis.readFloat();
		String s=dis.readLine();
		dis.close();
		System.out.println(i+"\t"+f+"\t"+s);
		System.out.println("Done");
	}

}
