package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.Branch;

public class BranchDao {
	public List<Branch> getAllBranches() throws SQLException
	{
		Connection con = ConnectionFactory.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM Branch");
		List<Branch> branchList=new ArrayList<>();
		while(rs.next())
		{
			//if the method returns one Branch, the return type is Branch
			//this method is going to return lot of branches
			//if there are 20 records in Branch table, then while loop iterates 20 times
			//each time we create one Branch object
			Branch branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3));
			branchList.add(branch);
		}
		return branchList;
	}
	public Branch findBranchById(String bid) throws SQLException
	{
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM Branch WHERE bid=?");
		st.setString(1, bid);
		ResultSet rs = st.executeQuery();
		Branch branch=null;
		if(rs.next())
		{
			//found a branch for given bid
			branch=new Branch(rs.getString(1), rs.getString(2), rs.getString(3));
		}
		return branch;
	}
	public int addBranch(Branch branch) throws SQLException
	{
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st=con.prepareStatement("insert into Branch VALUES(?,?,?)");
		st.setString(1, branch.getBid());
		st.setString(2, branch.getBname());
		st.setString(3, branch.getBcity());
		int no=st.executeUpdate();
		return no;
	}
	public int modifyBranch(Branch branch) throws SQLException
	{
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st=con.prepareStatement("UPDATE Branch SET bname=?, bcity=? WHERE bid=?");
		
		st.setString(1, branch.getBname());
		st.setString(2, branch.getBcity());
		st.setString(3, branch.getBid());
		int no=st.executeUpdate();
		return no;
		
	}
	public int removeBranch(String bid) throws SQLException
	{
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st=con.prepareStatement("DELETE FROM Branch WHERE bid=?");
		
		st.setString(1, bid);
		int no=st.executeUpdate();
		return no;
		
	}
}
