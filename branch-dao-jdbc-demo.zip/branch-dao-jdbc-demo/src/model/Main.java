package model;

import java.sql.SQLException;
import java.util.List;

import entity.Branch;

public class Main {

	public static void main(String[] args) throws SQLException {
//		lets test dao methods
		BranchDao bdao=new BranchDao();
//		List<Branch> branchList = bdao.getAllBranches();
//		for(Branch b:branchList)
//			System.out.println(b);
		
//		Branch branch = bdao.findBranchById("B00011");
//		if(branch==null)
//			System.out.println("No branch found");
//		else
//			System.out.println(branch);
		
//		Branch branch=new Branch("B00054", "ABCD Road", "Chennai");
//		int no=bdao.addBranch(branch);
//		System.out.println(no+" row(s) affected");
		
//		Branch branch=new Branch("B00054", "XYZ Road", "Chennai");
//		int no = bdao.modifyBranch(branch);
//		System.out.println(no+" row(s) affected");
		
//		int no=bdao.removeBranch("B00054");
//		System.out.println(no+" row(s) affected");
	}

}
