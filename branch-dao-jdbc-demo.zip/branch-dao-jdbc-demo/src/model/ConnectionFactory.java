package model;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ConnectionFactory {
	public static Connection getConnection() throws SQLException
	{
//		Driver driver=new com.mysql.jdbc.Driver();
		//how can i create an object of a class where class name is in String variable
		
//		DriverManager.registerDriver(driver);
		//read from properties file
		ResourceBundle rb = ResourceBundle.getBundle("database");
		String driver=rb.getString("driver");
		String url=rb.getString("url");
		String username=rb.getString("username");
		String password=rb.getString("password");
		Connection con = DriverManager.getConnection(url,username,password);
		return con;
	}
	
}
