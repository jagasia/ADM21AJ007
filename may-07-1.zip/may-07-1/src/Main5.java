class Calculator
{
	public synchronized void display()
	{
		String threadName = Thread.currentThread().getName();
		System.out.println("Display method entered by "+threadName);
		System.out.println(threadName+" is going to enter for loop");
		for(int i=0;i<10;i++)
		{
//			synchronized (this) {
				System.out.println();
				try {				
					System.out.println(threadName+" : "+i);
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
//			}
		}
		System.out.println(threadName+" has exited the for loop");
	}
}

class Thread1 extends Thread 
{
	private Calculator c;
	public Thread1() {}
	
	public Thread1(Calculator c) {	
		this.c = c;
	}

	public void run()
	{
		c.display();
	}
}

public class Main5 {

	public static void main(String[] args) {
		Calculator calc=new Calculator();
		Thread1 t1=new Thread1(calc);
		Thread1 t2=new Thread1(calc);
		t1.setName("Sahil");
		t2.setName("Pratik");
		t1.start();
		t2.start();
	}

}
