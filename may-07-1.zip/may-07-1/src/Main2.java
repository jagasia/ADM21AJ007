class T1 implements Runnable
{

	@Override
	public void run() {
		for(int i=100001;true;i+=2)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
class T2 implements Runnable
{

	@Override
	public void run() {
		for(int i=102;true;i+=2)
		{
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class Main2 {

	public static void main(String[] args) {
		Thread odd=new Thread(new T1());
		Thread even=new Thread(new T2());
		odd.start();
		even.start();

	}

}
