import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class Main8 {

	public static void main(String[] args) {
		List<Employee> employees=new ArrayList<>();
		employees.add(new Employee(1, "Ram", "Kumar", 1234567.0, "ECE"));
		employees.add(new Employee(7, "Alexander", "Babu", 1234567.0,"Mech"));
		employees.add(new Employee(9, "Yogi", "Babu", 1234567.0,"ECE"));
		employees.add(new Employee(8, "Ram", "Kumar", 1234567.0,"Civil"));		
		employees.add(new Employee(2, "Siva", "Kumar", 84383.0,"Mech"));
		employees.add(new Employee(3, "Rama", "Krishna", 747474.0,"Mech"));
		employees.add(new Employee(4, "Siva", "Raja", 383838.0,"ECE"));
		employees.add(new Employee(5, "Rama", "Nathan", 199111.0,"Mech"));
		employees.add(new Employee(6, "John", "Kennedy", 1024567.0,"ECE"));
		//map is used to translate a complex object into simple type
		//that means, employee has lot of properties, map is used to specify the property we are interested in
//		List<String> result = employees.stream()
//		.map(Employee->Employee.getFirstName())
//		.map((a)->a.toUpperCase())
//		.distinct()
//		.collect(Collectors.toList());
//		for(String e:result)
//			System.out.println(e);
		
		//display the number of employees present in each department (similar to group by in sql)
		Map<String, Double> result = employees.stream()
		.collect(Collectors.groupingBy(Employee::getDepartmentName, Collectors.summingDouble(Employee::getSalary)));
		
		for(Entry<String, Double> e:result.entrySet())
			System.out.println(e);
		
		
	}

}
