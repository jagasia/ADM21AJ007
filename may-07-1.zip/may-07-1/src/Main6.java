import java.util.Arrays;
import java.util.Comparator;

class IntegerComparator implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
		// TODO Auto-generated method stub
		return o2-o1;
	}
	
}

public class Main6 {

	public static void main(String[] args) {
		Integer arr[]= {9,3,8,10,11,22,12,55,35};
		Arrays.sort(arr, (o1,o2)->o2-o1);
//		Arrays.sort(arr,new IntegerComparator());
//		Arrays.sort(arr,new Comparator<Integer>() {
//
//			@Override
//			public int compare(Integer o1, Integer o2) {
//				// TODO Auto-generated method stub
//				return o2-o1;
//			}
//		});
		for(Integer x:arr)
			System.out.println(x);
	}

}
