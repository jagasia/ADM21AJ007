import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main7 {

	public static void main(String[] args) {
		List<String> countries=new ArrayList<>();
		countries.add("India");
		countries.add("Pakistan");
		countries.add("Sri lanka");
		countries.add("China");
		countries.add("Bangladesh");
		countries.add("Japan");
		countries.add("Australia");
		countries.add("Bhutan");
		countries.add("Nepal");
		countries.add("Turkey");
		countries.add("Netherlands");
		countries.add("United States of America");
		countries.add("Argentina");
		countries.add("Brazil");
		
		
		//you have this stream() method in every collection
//		countries.stream()
//		.sorted(Collections.reverseOrder())		
//		.forEach(System.out::println);
//		
		
		//sort countries based on length of the country name
//		countries.stream()
//		.sorted((a,b)->b.length()-a.length())
//		.forEach(System.out::println);
		
		//filter the countries. Only countries starting with "A" is required
//		countries.stream()
//		.filter((s)->s.substring(0,1).equals("A"))
//		.forEach(System.out::println);

		//filter the countries. The countries name that are not starting with "A" are required
//		countries.stream()
//		.filter((s)->!s.substring(0,1).equals("A"))
//		.filter((s)->!s.substring(0,1).equals("B"))
//		.forEach(System.out::println);
		
		//store the result of this stream in a list
		List<String> result = countries.stream()
		.filter((s)->!s.substring(0,1).equals("A"))
		.filter((s)->!s.substring(0,1).equals("B"))
		.collect(Collectors.toList());
		
//		System.out.println(result);
		for(String s : result)
			System.out.println(s);
	}

}
