class MyThread extends Thread
{
	public void run()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println(getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
public class Main4 {

	public static void main(String[] args) throws InterruptedException {
		MyThread t1, t2, t3, t4;
		t1=new MyThread();
		t1.setName("Thread 1");
		t2=new MyThread();
		t2.setName("Thread 2");
		t3=new MyThread();
		t3.setName("Thread 3");
		t4=new MyThread();
		t4.setName("Thread 4");
		t1.start();
		t2.start();
		t1.join(); //whoever started, can continue. those who have not yet started, pls wait. Whoever started, can complete. then you can start.
		t3.start();
		t4.start();
	}

}
