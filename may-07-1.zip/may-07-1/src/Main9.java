import java.time.LocalDate;
import java.time.Period;

public class Main9 {

	public static void main(String[] args) {
		LocalDate dob=LocalDate.of(1999, 01, 01);
		LocalDate today=LocalDate.of(2021, 05, 07);
		
		//age based on dob
		Period age = Period.between(dob, today);
		System.out.printf("You are %d years, %d months and %d days young!",age.getYears(),age.getMonths(),age.getDays());
	}

}
