import java.util.Date;

public class CalculatePremiumService {
	public boolean checkOwnerDetails(String name, String mobile)
	{
		if(name.length()<2)
			return false;
		if(!name.matches("[A-Z][a-z]"))
			return false;
		if(mobile.length()!=10)
			return false;
		char first=mobile.charAt(0);
		int firstDigit=first-48;
		if(firstDigit<6 || firstDigit>9)
			return false;
		if(!mobile.matches("[0-9]{10}"))
			return false;
		return true;
	}
//	public Double getPremiumAmount(PropertyDetails propertyDetails)
//	{
//		
//		return 0.90;
//	}
//	public boolean validatePropertyParameters(PropertyDetails propertyDetails)
//	{
//		if(propertyDetails.getHouseholdValuation()<0)
//			return false;
//		if(propertyDetails.getBuildUpArea()<400 || propertyDetails.getBuildUpArea()>15000)
//			return false;
//		if(propertyDetails.getReconstructionCost()<1000 || propertyDetails.getReconstructionCost()>10000)
//			return false;
//		int currentYear=new Date().getYear()+1900;
//		if(propertyDetails.getBuiltYear()<2000 || propertyDetails.getBuiltYear()>currentYear)
//			return false;
//		
//		return false;
//	}
//	public Double calculatePremiumByPropertyAge(PropertyDetails propertyDetails)
//	{
//		return 0.90;//dummy
//	}
}
