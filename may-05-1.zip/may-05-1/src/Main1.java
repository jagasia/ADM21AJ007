import java.util.PriorityQueue;
import java.util.Queue;

public class Main1 {

	public static void main(String[] args) {
		Queue<Integer> marks=new PriorityQueue<>();
		marks.add(100);
		marks.add(10);
		marks.add(50);
		marks.add(45);
		
		for(Integer i : marks)
			System.out.println(i);
	}

}
