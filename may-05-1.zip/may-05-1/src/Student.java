import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Student implements Comparable<Student>
{
	private Integer id;
	private String firstName;
	private String lastName;
	private Date dateOfBirth;
	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	
	public Student() {}

	public Student(Integer id, String firstName, String lastName, Date dateOfBirth) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
	}
	public Student(Integer id, String firstName, String lastName, String dateOfBirth) throws ParseException {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = sdf.parse(dateOfBirth);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ sdf.format(dateOfBirth) + "]";
	}

	@Override
	public int compareTo(Student o) {
//		return o.getId().compareTo(this.getId());
		return o.getDateOfBirth().compareTo(this.getDateOfBirth());
	}

	
}
