import java.util.Iterator;
import java.util.NavigableSet;
import java.util.TreeSet;

public class Main_NavigableSet {
	public static void main(String[] args) {
		NavigableSet<Integer> marks=new TreeSet<Integer>();
		marks.add(50);
		marks.add(150);
		marks.add(51);
		marks.add(501);
		marks.add(502);
		marks.add(52);
		marks.add(250);
		marks.add(350);
		marks.add(53);
		marks.add(503);
		Iterator<Integer> it = marks.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		NavigableSet<Integer> result = marks.descendingSet();
		Iterator<Integer> it1 = result.iterator();
		while(it1.hasNext())
			System.out.println(it1.next());
		
		Iterator<Integer> it3 = marks.descendingIterator();
		while(it3.hasNext())
			System.out.println(it3.next());
	}
}
