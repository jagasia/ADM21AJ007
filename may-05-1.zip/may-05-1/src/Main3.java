import java.text.ParseException;
import java.util.PriorityQueue;
import java.util.Queue;

public class Main3 {

	public static void main(String[] args) throws ParseException {
		Queue<Student> students=new PriorityQueue<>();
		students.add(new Student(100, "Rama", "Krishna", "2000-01-01"));
		students.add(new Student(1, "Suresh", "Krishna", "1999-01-01"));
		students.add(new Student(20, "Rama", "Rajan", "1991-01-01"));
		students.add(new Student(15, "Ram", "Kumar", "2001-01-01"));
		students.add(new Student(10, "Siva", "Kumar", "2010-01-01"));
		
		while(students.size()>0)
		{
			System.out.println(students.remove());
		}
	}

}
