import java.util.PriorityQueue;
import java.util.Queue;

public class Main2 {

	public static void main(String[] args) {
		Queue<Employee> que=new PriorityQueue<>((a,b)->b.getSalary().compareTo(a.getSalary()));
		que.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		que.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		que.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		que.add(new Employee(1, "Ram", "Kumar", 1234567.0));		
		que.add(new Employee(2, "Siva", "Kumar", 84383.0));
		que.add(new Employee(3, "Rama", "Krishna", 747474.0));
		que.add(new Employee(4, "Siva", "Raja", 383838.0));
		que.add(new Employee(5, "Rama", "Nathan", 199111.0));
		que.add(new Employee(6, "John", "Kennedy", 1024567.0));
		while(que.size()>0)
		{
			System.out.println(que.remove());
		}
	}

}
