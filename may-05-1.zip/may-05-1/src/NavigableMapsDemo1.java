import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Set;
import java.util.TreeMap;

public class NavigableMapsDemo1 {

	public static void main(String[] args) {
		NavigableMap<Integer, String> countries=new TreeMap<>();
		countries.put(5, "Bharath");
		countries.put(1, "Ceylon");
		countries.put(1, "Sri lanka");
		countries.put(2, "Japan");
		countries.put(7, "Australia");
		countries.put(5, "India");

		for(Entry<Integer, String> e:countries.entrySet())
			System.out.println(e);
	}

}
