import java.text.SimpleDateFormat;
import java.util.Date;

public class Main4 {

	public static void main(String[] args) {
		Date dt=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("EEEE");

		System.out.println(sdf.format(dt));
	}

}
