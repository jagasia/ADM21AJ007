import java.util.ArrayList;
import java.util.List;

public class Main1 {

	public static void main(String[] args) {
		ArrayList<String> countries=new ArrayList<>();
		countries.add("India");
		countries.add("Australia");
		countries.add("Sri lanka");
		countries.add("Pakistan");
		countries.add("China");
		countries.add("Bangladesh");
		countries.add("Japan");
		
		if(countries.contains("Japan"))
			System.out.println("Japan is found");
		else
			System.out.println("Japan is NOT found");
	}

}
