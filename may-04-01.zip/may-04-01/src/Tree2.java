import java.util.TreeSet;
import java.util.Collections;
import java.util.Set;

public class Tree2 {

	public static void main(String[] args) {
		Set<Employee> employeeSet=new TreeSet<>();
		employeeSet.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeSet.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeSet.add(new Employee(2, "Siva", "Kumar", 84383.0));
		employeeSet.add(new Employee(3, "Rama", "Krishna", 747474.0));
		employeeSet.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeSet.add(new Employee(4, "Siva", "Raja", 383838.0));
		employeeSet.add(new Employee(5, "Rama", "Nathan", 199111.0));
		employeeSet.add(new Employee(6, "John", "Kennedy", 1024567.0));
		employeeSet.add(new Employee(1, "Ram", "Kumar", 1234567.0));		
		
//		Collections.sort(employeeSet);		NOT ALLOWED. Set cannot be sort later
		System.out.println("Hello world");
		for(Employee e : employeeSet)
			System.out.println(e);
		
		
	}

}
