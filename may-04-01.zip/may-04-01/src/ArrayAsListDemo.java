import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ArrayAsListDemo {

	public static void main(String[] args) {
		List<Integer> marks=Arrays.asList(2,3,4,5,6,7,8);
		for(Integer x:marks)
			System.out.println(x);
		//need to display in reverse order
		System.out.println("Reverse");
		Collections.reverse(marks);
		for(Integer x:marks)
			System.out.println(x);
	}

}
