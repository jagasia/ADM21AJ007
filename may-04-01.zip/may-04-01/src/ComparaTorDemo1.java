import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

//create an external comparator for integer
class JagComparator implements Comparator<Integer>
{

	@Override
	public int compare(Integer o1, Integer o2) {
//		return o1.compareTo(o2);
		return o2-o1;
	}
	
}

public class ComparaTorDemo1 {

	public static void main(String[] args) {
		Set<Integer> marks=new TreeSet<>(new JagComparator());
		marks.add(100);
		marks.add(30);
		marks.add(50);
		marks.add(45);
		marks.add(30);
		marks.add(90);
		marks.add(50);
		marks.add(70);
		marks.add(80);
		marks.add(60);
		for(Integer i:marks)
			System.out.println(i);
	}

}
