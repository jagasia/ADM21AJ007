import java.io.File;

public class FileDemo1 {

	public static void main(String[] args) {
		File f=new File("D:\\Jag\\amit");
		//using this object rep of file, i can get lot of info about the file
		System.out.println(f.getAbsolutePath());
		String[] arr = f.list();
		
		for(String s:arr)
			System.out.println(s);
	}

}
