import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<Integer> marks=new TreeSet<>();
		marks.add(30);
		marks.add(90);
		marks.add(10);
		marks.add(110);
		marks.add(40);
		marks.add(35);
		marks.add(90);
		System.out.println(marks);
	}

}
