import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class Main12 {

	public static List<Integer> removeDuplicates(List<Integer> input)
	{
		//write your code here
		LinkedHashSet<Integer> temp=new LinkedHashSet<Integer>(input);
		List<Integer> result=new ArrayList<>(temp);
		return result;
	}
	
	public static void main(String[] args) {
		List<Integer> input=new ArrayList<>();
		input.add(40);
		input.add(40);
		input.add(100);
		input.add(90);
		input.add(90);
		input.add(140);
		input.add(90);
		input.add(50);
		input.add(100);
		List<Integer> result = removeDuplicates(input);
		for(Integer i:result)
			System.out.println(i);
	}
}
