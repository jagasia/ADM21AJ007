import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class Stringdemo1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		//split by space
//		StringTokenizer st=new StringTokenizer(input," .,");
		input=input.toLowerCase();
		String[] arr = input.split("[,;:.?! ]");
		int noOfWords=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i].length()>0)
				noOfWords++;
		}
		System.out.println("Number of words "+noOfWords);
		TreeSet<String> set=new TreeSet<>();
		for(String s:arr)
		{
			if(s.length()>0)
				set.add(s);
		}
		noOfWords=set.size();
		System.out.println("Number of unique words "+noOfWords);
		int i=1;
		
		for(String s:set)
		{
			System.out.println(i++ +"."+s);
		}
	}

}
