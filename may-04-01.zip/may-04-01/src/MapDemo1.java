import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MapDemo1 {

	public static void main(String[] args) {
//		HashMap<Integer, String> map=new HashMap<>();
		Map<Integer, String> map=new HashMap<Integer, String>();
		map.put(1, "Rajastan");
		map.put(2, "Tamil Nadu");
		map.put(3, "Karnataka");
		map.put(4, "Utter Pradesh");
		map.put(5, "Andra Pradesh");
		map.put(5, "Telangana");
	
		System.out.println(map.get(4));
	}

}
