import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
class EmployeeComparator implements Comparator<Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		return o2.getSalary().compareTo(o1.getSalary());
	}
	
}
public class ComparatorDemo2 {

	public static void main(String[] args) {
		List<Employee> employeeList=new ArrayList<>();
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));		
		employeeList.add(new Employee(2, "Siva", "Kumar", 84383.0));
		employeeList.add(new Employee(3, "Rama", "Krishna", 747474.0));
		employeeList.add(new Employee(4, "Siva", "Raja", 383838.0));
		employeeList.add(new Employee(5, "Rama", "Nathan", 199111.0));
		employeeList.add(new Employee(6, "John", "Kennedy", 1024567.0));
		
//		Collections.sort(employeeList, new EmployeeComparator());	//will work only if comparable or comparator is used
		
		Collections.sort(employeeList, (o1, o2)->o2.getSalary().compareTo(o1.getSalary()));
		
		for(Employee e:employeeList)
			System.out.println(e);
		
	}

}
