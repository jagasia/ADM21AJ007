import java.util.ArrayList;
import java.util.List;

public class Main11 {

	public static void main(String[] args) {
		List<Integer> marks=new ArrayList<Integer>();
		marks.add(90);
		marks.add(100);
		marks.add(1);
		marks.add(70);
		marks.add(50);
		marks.add(40);
		marks.add(60);
		System.out.println(marks.size());
	}

}
