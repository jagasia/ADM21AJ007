import java.util.ArrayList;
import java.util.List;

public class Main4 {

	public static void main(String[] args) {
		List<Employee> employeeList=new ArrayList<>();
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));
		employeeList.add(new Employee(1, "Ram", "Kumar", 1234567.0));		
		employeeList.add(new Employee(2, "Siva", "Kumar", 84383.0));
		employeeList.add(new Employee(3, "Rama", "Krishna", 747474.0));
		employeeList.add(new Employee(4, "Siva", "Raja", 383838.0));
		employeeList.add(new Employee(5, "Rama", "Nathan", 199111.0));
		employeeList.add(new Employee(6, "John", "Kennedy", 1024567.0));
		
		Employee temp=new Employee(6, "abcd", "efgh", 1234567.0);
//		if(employeeList.contains(temp))
//			System.out.println(" is found");
//		else
//			System.out.println("Not found");
		//remove an element
		
//		employeeList.remove(temp);
			employeeList.remove(5);
			
			for(Employee e:employeeList)
				System.out.println(e);
	}
	
}
