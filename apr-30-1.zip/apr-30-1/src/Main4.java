import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	}

}
