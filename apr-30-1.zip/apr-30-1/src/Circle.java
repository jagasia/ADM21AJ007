
public class Circle extends Shape {
	private int radius;

	public Circle() {}
	
	

	public Circle(String name, String color, String backgroundColor, int radius) {
		super(name, color, backgroundColor);
		this.radius=radius;
	}



	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	@Override
	public String toString() {
		return super.toString()+";Circle [radius=" + radius + "]";
	}
	
}
