
public class Triangle extends Shape{
	private int breadth;
	private int height;
	public Triangle() {}
	
	public Triangle(String name, String color, String backgroundColor,int breadth, int height) {
		super(name, color, backgroundColor);	
		this.breadth=breadth;
		this.height=height;
	}

	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	@Override
	public String toString() {
		return super.toString()+";Triangle [breadth=" + breadth + ", height=" + height + "]";
	}

	
}
