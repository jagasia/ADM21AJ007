class Person
{
	public void speak()
	{
		System.out.println("Person speaks");
	}
}

class Student extends Person
{
	public void speak()
	{
		System.out.println("Student speaks");
	}
}
class Teacher extends Person
{
	public void speak()
	{
		System.out.println("Teacher speaks");
	}
}
public class Main {

	public static void main(String[] args) {
		Person rama;
		rama=new Teacher();
		rama.speak();		//rama speaks like a teacher
		
		rama=new Student();
		rama.speak();		//rama speaks like a student
	}

}
