
public class Main_Account {

	public static void main(String[] args) {
		AccountDetails accountDetails=new AccountDetails();		
		Account account = accountDetails.getAccountDetails();
		int amount=accountDetails.getWithdrawAmount();
		account.withdraw(amount);
	}

}
