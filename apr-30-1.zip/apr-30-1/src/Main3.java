abstract class Furniture
{
	public void acceptDetails()
	{
		System.out.println("Furniture accept details");
	}
	public abstract void displayDetails();
	
}
class Chair extends Furniture
{
	public void displayDetails()
	{
		System.out.println("Chair display details");
	}
	@Override
	public void acceptDetails() {
		System.out.println("Chai accept details");
	}
	
}

public class Main3 {

	public static void main(String[] args) {
		Furniture f;
		f=new Chair();
		f.acceptDetails();
		f.displayDetails();
	}

}
