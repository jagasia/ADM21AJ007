import java.util.Scanner;

public class AccountDetails {
	public Account getAccountDetails()
	{
		int accountId;
		String accountType;
		int balance;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter account id:");
		accountId=sc.nextInt();
		System.out.println("Enter account type:");
		accountType=sc.next();
		
		do {
			System.out.println("Enter balance:");			
		balance=sc.nextInt();
			if(balance<0)
			{
				System.out.println("Balance should be positive");
				continue;
			}else
			{
				break;
			}
		}while(true);
		
//		Account account=new Account();
//		account.setAccountId(accountId);
//		account.setAccountType(accountType);
//		account.setBalance(balance);
		
		Account account=new Account(accountId, accountType, balance);
		
		
		return account;
	}
	public int getWithdrawAmount()
	{
		Scanner sc=new Scanner(System.in);
		int amount;
		System.out.println("Enter amount to be withdrawn:");
		amount=sc.nextInt();
		if(amount<=0)
		{
			System.out.println("Amount should be positive");
		}
		return amount;
	}
}
