

public class Main_Shapes {

	public static void main(String[] args) {
//		Shape s=new Shape();
//		s.setName("A shape");
//		s.setColor("Blue");
//		s.setBackgroundColor("White");
//		//some times, we have few information available while creating object
		//remaining information can be set later using setter methods
		
		//another approach
//		Shape s1=new Shape("Another Shape", "Green", "Brown");
		
		//this approach is possible if all values are avaiable initially'
		
		
		Shape s;		//this is not an object. this is just a ref variable
		//ref var of abstract class can be created. but objects cannot be created
		s=new Circle();
		s=new Triangle();
		
		
		
		
		
		Triangle t=new Triangle("Pyramid", "Black", "Yellow", 10, 20);
		System.out.println(t);
	}

}
