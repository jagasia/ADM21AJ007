import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main4 {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		String bid, bname, bcity;
		System.out.println("Branch Id:");
		bid=sc.nextLine();
		System.out.println("Branch Name:");
		bname=sc.nextLine();
		System.out.println("Branch City:");
		bcity=sc.nextLine();
		
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st = con.prepareStatement("UPDATE Branch SET bname=?, bcity=? WHERE bid=?");
		st.setString(1, bname);
		st.setString(2, bcity);
		st.setString(3, bid);
		int no=st.executeUpdate();
		System.out.println(no+" row(s) affected");
	}

}
