import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the branch id:");
		String bid=sc.next();
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st = con.prepareStatement("SELECT * FROM Branch WHERE bid=?");
		st.setString(1, bid);
		ResultSet rs = st.executeQuery();
		if(rs.next())
			System.out.printf("%6s\t%-30s\t%-15s\n",rs.getString(1), rs.getString(2), rs.getString(3));
		else
			System.out.println("No branch found for "+bid);
		con.close(); 		//good practice
	}

}
