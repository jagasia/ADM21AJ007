import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) throws SQLException {
		System.out.println("HEllo world");
		Driver driver=new com.mysql.jdbc.Driver();
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM Customer");
		while(rs.next())
		{
			System.out.println(rs.getString(1));
		}
	}

}
