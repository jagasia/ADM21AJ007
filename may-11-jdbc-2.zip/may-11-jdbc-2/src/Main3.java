import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Main3 {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		String bid, bname, bcity;
		System.out.println("Branch Id:");
		bid=sc.nextLine();
		System.out.println("Branch Name:");
		bname=sc.nextLine();
		System.out.println("Branch City:");
		bcity=sc.nextLine();
		//lets add record into the Branch table
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement st = con.prepareStatement("INSERT INTO Branch VALUES(?,?,?)");
		st.setString(1, bid);
		st.setString(2, bname);
		st.setString(3, bcity);
		int no = st.executeUpdate();
		System.out.println(no+" row(s) affected");
	}

}
