import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String customerName;
		long contactNumber;
		String emailId;
		int age;
		System.out.println("Enter the Name:");
		customerName = sc.next();
		System.out.println("Enter the ContactNumber:");
		contactNumber = sc.nextLong();
		System.out.println("Enter the EmailId:");
		emailId = sc.next();
		System.out.println("Enter the Age:");
		age = sc.nextInt();
		Customer customer = new Customer();
		customer.setCustomerName(customerName);
		customer.setContactNumber(contactNumber);
		customer.setEmailId(emailId);
		customer.setAge(age);
		System.out.println("Name:"+customer.getCustomerName());
		System.out.println("ContactNumber:"+customer.getContactNumber());
		System.out.println("EmailId:"+customer.getEmailId());
		System.out.println("Age:"+customer.getAge());
	}

}
