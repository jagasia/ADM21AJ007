import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		char letter=sc.next().charAt(0);		//to get 1 char input
		String letter=sc.next();
		String sentence=sc.nextLine();
		if(sentence.equals(""))
			sentence=sc.nextLine();
		//case insensitive. os
		sentence=sentence.toLowerCase();
		//split the sentence by space. so that we get words as string array
		StringTokenizer st=new StringTokenizer(sentence," ");
		int score=0;
		int i=0;
		while(st.hasMoreTokens())
		{
			String word=st.nextToken();
//			i++;
//			if(i>=1 && i<=3)
//				if(!word.substring(0,1).equalsIgnoreCase(letter))
//				{
//					score=0;
//					break;
//				}
			if(!word.substring(0,1).equalsIgnoreCase(letter))
				continue;
			else
				i++;
			if(i==3)
				score=2;
			
			
			else if(i>3)
				score+=2;
		}
		if(score>0)
			System.out.println("Good, You get a score of "+score);
		else
			System.out.println("No score");
	}

}
