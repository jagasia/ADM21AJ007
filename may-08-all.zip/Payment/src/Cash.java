
public class Cash extends Payment{
	private int cashAmount;
	
	public int getCashAmount() {
		return cashAmount;
	}
	public void setCashAmount(int cashAmount) {
		this.cashAmount = cashAmount;
	}
	@Override
	public boolean payAmount() {
		return cashAmount>=getDueAmount();
	}

}
