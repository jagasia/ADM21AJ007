
public class Credit extends Payment {
	private int creditCardNo;
	private String cardType;
	private int creditCardAmount;
	
	public int getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(int creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public int getCreditCardAmount() {
		return creditCardAmount;
	}

	public void setCreditCardAmount(int creditCardAmount) {
		this.creditCardAmount = creditCardAmount;
	}

	@Override
	public boolean payAmount() {
		double serviceTax=0.0;
		switch(cardType)
		{
		case "silver":		//2%
			setCreditCardAmount(10000);
			serviceTax=(double)getDueAmount()*2.0/100;
			break;
		case "gold":		//5%
			setCreditCardAmount(50000);
			serviceTax=(double)getDueAmount()*5.0/100;
			break;
		case "platinum":	//10%
			setCreditCardAmount(100000);
			serviceTax=(double)getDueAmount()*10.0/100;
			break;
		}
		double totalDue = getDueAmount()+serviceTax;
//		if(creditCardAmount>=totalDue)
//			return true;
//		else
//			return  false;
		
		boolean result = creditCardAmount>=totalDue;
		creditCardAmount-=totalDue;
		return result;
	}

}
