
public class Bill {
	public String processPayment(Payment obj)
	{
		String message="Payment done successfully via ";
		if(obj.payAmount())
		{
			//payment is successful
			if(obj instanceof Cash)
				message+="cash";
			else if(obj instanceof Cheque)
				message+="cheque";
			else
			{
				//for credit card alone, remaining amount 
				Credit cc=(Credit) obj;
				String cardType=cc.getCardType();
				int remainingAmount = cc.getCreditCardAmount();
				message+="creditcard. Remaining amount in your "+cardType+" card is "+remainingAmount;
			}
		}
		else
		{
			message="Payment not done and your due amount is "+obj.getDueAmount();
		}
		return message;
	}
}
