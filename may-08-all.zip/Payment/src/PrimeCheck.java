import java.util.Scanner;

public class PrimeCheck {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		boolean flag=true;
		for(int i=2;i<=no/2;i++)
		{
			if(no%i==0)
			{
				//not a prime no
				flag=false;
				break;
			}
		}
		if(flag)
			System.out.println("Prime");
		else
			System.out.println("NOt prime");
	}

}
