import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

public class Cheque extends Payment{
	private String chequeNo;
	private int chequeAmount;
	private Date dateOfIssue;
	public String getChequeNo() {
		return chequeNo;
	}
	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}
	public int getChequeAmount() {
		return chequeAmount;
	}
	public void setChequeAmount(int chequeAmount) {
		this.chequeAmount = chequeAmount;
	}
	public Date getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	@Override
	public boolean payAmount()
	{
		//today is 01-01-2020	dde-MM-yyyy
		if(chequeAmount<getDueAmount())
			return false;
		//check if cheque is less than 5 months
				
		LocalDate cdate=LocalDate.of(dateOfIssue.getYear()+1900, dateOfIssue.getMonth()+1, dateOfIssue.getDate());
		LocalDate today=LocalDate.of(2020, 1, 1);
		Period diff=Period.between(cdate, today);
		if(diff.getMonths()>6)
			return false;	//temp
		return true;
	}
}
