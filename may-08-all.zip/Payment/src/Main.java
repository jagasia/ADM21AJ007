import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
//		Date today=new Date();
//		System.out.println(today.getYear()+1900);		//2021	-	1900	=121
//		System.out.println(today.getMonth()+1);
//		System.out.println(today.getDate());

		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the due amount:");
		int dueAmount = sc.nextInt();
		System.out.println("Enter the nmode of payment(cheque/cash/credit");
		String paymentMode = sc.next();
		String message="";
		Bill bill=new Bill();
		switch (paymentMode) {
		case "cash":
			Cash cashPayment = new Cash();
			System.out.println("Enter the cash amount:");
			int amount = sc.nextInt();			
			cashPayment.setCashAmount(amount);
			cashPayment.setDueAmount(dueAmount);
			cashPayment.setDueAmount(dueAmount);
			message=bill.processPayment(cashPayment);
			break;
		case "cheque":
			Cheque chequePayment = new Cheque();
			System.out.println("Enter the cheque number:");
			String chequeNo = sc.next();
			System.out.println("Enter the cheque amount:");
			int chequeAmount = sc.nextInt();
			System.out.println("Enter the date of issue:");
			String dt = sc.next();
			
			Date dateOfIssue = sdf.parse(dt);
			chequePayment.setChequeNo(chequeNo);
			chequePayment.setChequeAmount(chequeAmount);
			chequePayment.setDateOfIssue(dateOfIssue);
			chequePayment.setDueAmount(dueAmount);
			message=bill.processPayment(chequePayment);
			break;
		case "credit":
			Credit creditPayment = new Credit();
			System.out.println("Enter the credit card number:");
			int creditCardNo = sc.nextInt();
			System.out.println("Enter the card type(silver,gold,platinum):");
			String cardType = sc.next();			
			creditPayment.setCreditCardNo(creditCardNo);
			creditPayment.setCardType(cardType);
			creditPayment.setDueAmount(dueAmount);
			message=bill.processPayment(creditPayment);
			break;
		}
		System.out.println(message);
	}

}
