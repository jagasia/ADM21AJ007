
public class Call {
	private int callId;
	private long calledNumber;
	float duration;
	public int getCallId() {
		return callId;
	}
	public void setCallId(int callId) {
		this.callId = callId;
	}
	public long getCalledNumber() {
		return calledNumber;
	}
	public void setCalledNumber(long calledNumber) {
		this.calledNumber = calledNumber;
	}
	public float getDuration() {
		return duration;
	}
	public void setDuration(float duration) {
		this.duration = duration;
	}
	public void parseData(String callDetails)
	{
		String[] arr = callDetails.split(":");
		this.callId=Integer.parseInt(arr[0]);
		this.calledNumber=Long.parseLong(arr[1]);
		this.duration=Float.parseFloat(arr[2]);
	}
	
}
